package com.photomagic.ai;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final int PICK_IMAGE = 1001;
    private ImageView preview;
    private Bitmap original, edited;
    private float brightness = 1f;
    private String filter = "none";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t;
    }
    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); return b;
    }
    private void buildUi() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(20), dp(18), dp(16)); root.setBackgroundColor(Color.rgb(16,16,26));
        TextView title = text("PhotoMagic AI", 27, Color.WHITE); title.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(48)));
        TextView subtitle = text("Your photos, your creativity", 14, Color.LTGRAY);
        root.addView(subtitle);
        preview = new ImageView(this); preview.setBackgroundColor(Color.rgb(35,35,49)); preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams imageLp = new LinearLayout.LayoutParams(-1, 0, 1f); imageLp.setMargins(0, dp(16), 0, dp(12)); root.addView(preview, imageLp);
        Button choose = button("＋  Choose photo"); choose.setOnClickListener(v -> pickImage()); root.addView(choose, fullWidth());
        TextView brightLabel = text("Brightness", 14, Color.WHITE); brightLabel.setPadding(0, dp(10), 0, 0); root.addView(brightLabel);
        SeekBar seek = new SeekBar(this); seek.setMax(200); seek.setProgress(100);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) { brightness = p / 100f; render(); }
            public void onStartTrackingTouch(SeekBar s) {} public void onStopTrackingTouch(SeekBar s) {}
        }); root.addView(seek);
        LinearLayout row1 = new LinearLayout(this); row1.setGravity(Gravity.CENTER); row1.addView(buttonWith("Original", () -> { filter="none"; brightness=1f; seek.setProgress(100); render(); }));
        row1.addView(buttonWith("B&W", () -> { filter="bw"; render(); })); row1.addView(buttonWith("Warm", () -> { filter="warm"; render(); })); root.addView(row1);
        LinearLayout row2 = new LinearLayout(this); row2.setGravity(Gravity.CENTER);
        row2.addView(buttonWith("↻ Rotate", () -> rotate())); row2.addView(buttonWith("Save photo", () -> savePhoto())); root.addView(row2);
        TextView note = text("Basic editor • works on-device • no OpenAI key", 11, Color.LTGRAY); note.setGravity(Gravity.CENTER); note.setPadding(0, dp(8), 0, 0); root.addView(note);
        setContentView(root);
    }
    private LinearLayout.LayoutParams fullWidth() { return new LinearLayout.LayoutParams(-1, dp(48)); }
    private Button buttonWith(String label, Runnable action) { Button b=button(label); b.setOnClickListener(v -> action.run()); return b; }
    private void pickImage() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT); i.setType("image/*");
        startActivityForResult(Intent.createChooser(i, "Select a photo"), PICK_IMAGE);
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try (InputStream in = getContentResolver().openInputStream(data.getData())) {
                original = BitmapFactory.decodeStream(in); brightness=1f; filter="none"; render();
            } catch (Exception e) { toast("Could not open that photo"); }
        }
    }
    private void render() {
        if (original == null) return;
        Bitmap out = Bitmap.createBitmap(original.getWidth(), original.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(out); Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        ColorMatrix cm = new ColorMatrix();
        if ("bw".equals(filter)) cm.setSaturation(0f);
        if ("warm".equals(filter)) {
            cm.set(new float[]{1.12f,0,0,0,8, 0,1.02f,0,0,3, 0,0,0.88f,0,0, 0,0,0,1,0});
        }
        float[] b = {brightness,0,0,0,0, 0,brightness,0,0,0, 0,0,brightness,0,0, 0,0,0,1,0};
        ColorMatrix bm = new ColorMatrix(b); cm.postConcat(bm);
        paint.setColorFilter(new ColorMatrixColorFilter(cm)); canvas.drawBitmap(original, 0, 0, paint);
        edited = out; preview.setImageBitmap(edited);
    }
    private void rotate() {
        if (original == null) { toast("Choose a photo first"); return; }
        Matrix m = new Matrix(); m.postRotate(90);
        original = Bitmap.createBitmap(original, 0, 0, original.getWidth(), original.getHeight(), m, true); render();
    }
    private void savePhoto() {
        if (edited == null) { toast("Choose a photo first"); return; }
        try {
            ContentValues values = new ContentValues(); values.put(MediaStore.Images.Media.DISPLAY_NAME, "PhotoMagic_" + System.currentTimeMillis() + ".jpg");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg"); values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PhotoMagicAI");
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new Exception("Save failed");
            try (OutputStream out = getContentResolver().openOutputStream(uri)) { edited.compress(Bitmap.CompressFormat.JPEG, 95, out); }
            toast("Saved to Pictures/PhotoMagicAI");
        } catch (Exception e) { toast("Could not save photo"); }
    }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
